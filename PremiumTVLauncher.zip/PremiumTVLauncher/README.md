# Premium TV Launcher

Launcher خفيف لـ Android TV / TV Box (كيخدم من Android 5.0 فما فوق، بما فيها Mi Box 4C / Android 6.0.1).

## كيفاش تحصل على APK
1. ارفع هاد المجلد كامل لـ repo جديد فـ GitHub (الفرع `main`).
2. سير لـ **Actions** وتسنى حتى يكمل "Build APK" (3-6 دقائق).
3. حل آخر run → **Artifacts** → حمل `PremiumLauncher-apk` (zip فيه `PremiumLauncher.apk`).
4. (اختياري) باش يتنشر فـ Releases: `git tag v1.0 && git push origin v1.0`.

## التثبيت فالبوكس
- فعل "Unknown sources" ونقل الـ APK بفلاشة أو ADB: `adb install PremiumLauncher.apk`
- اضغط زر Home وختار **Premium Launcher** → **Always**.

## التحكم
- OK: فتح التطبيق | OK مطولة: تثبيت فوق (Pin) أو معلومات التطبيق.
- الاسم فالترحيب: بدلو فـ `app/src/main/res/values/strings.xml` (`user_name`).
