package com.farid.tvlauncher;

import android.content.Intent;
import android.graphics.drawable.Drawable;

public class AppEntry {
    public final String label;
    public final String pkg;
    public final Intent intent;
    public final Drawable icon;
    public final Drawable banner;
    public boolean pinned;

    public AppEntry(String label, String pkg, Intent intent, Drawable icon, Drawable banner, boolean pinned) {
        this.label = label;
        this.pkg = pkg;
        this.intent = intent;
        this.icon = icon;
        this.banner = banner;
        this.pinned = pinned;
    }
}
