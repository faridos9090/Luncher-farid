package com.farid.tvlauncher;

import android.graphics.Outline;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.ViewOutlineProvider;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AppAdapter extends RecyclerView.Adapter<AppAdapter.VH> {

    public interface Listener {
        void onClick(AppEntry entry);

        void onLongClick(AppEntry entry);
    }

    private final List<AppEntry> items = new ArrayList<>();
    private final Listener listener;

    public AppAdapter(Listener listener) {
        this.listener = listener;
    }

    public void setItems(List<AppEntry> newItems) {
        items.clear();
        items.addAll(newItems);
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public VH onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_app, parent, false);
        return new VH(v);
    }

    @Override
    public void onBindViewHolder(@NonNull VH h, int position) {
        final AppEntry e = items.get(position);
        h.label.setText(e.label);
        h.pin.setVisibility(e.pinned ? View.VISIBLE : View.GONE);

        if (e.banner != null) {
            h.img.setScaleType(ImageView.ScaleType.CENTER_CROP);
            h.img.setPadding(0, 0, 0, 0);
            h.img.setBackground(null);
            h.img.setImageDrawable(e.banner);
        } else {
            int pad = h.dp(26);
            h.img.setScaleType(ImageView.ScaleType.FIT_CENTER);
            h.img.setPadding(pad, pad, pad, pad);
            h.img.setBackgroundResource(R.drawable.glass_bg);
            h.img.setImageDrawable(e.icon);
        }

        h.itemView.setOnClickListener(v -> listener.onClick(e));
        h.itemView.setOnLongClickListener(v -> {
            listener.onLongClick(e);
            return true;
        });
    }

    @Override
    public int getItemCount() {
        return items.size();
    }

    static class VH extends RecyclerView.ViewHolder {
        final View card;
        final ImageView img;
        final View border;
        final View pin;
        final TextView label;
        final float density;

        VH(@NonNull View itemView) {
            super(itemView);
            density = itemView.getResources().getDisplayMetrics().density;
            card = itemView.findViewById(R.id.card);
            img = itemView.findViewById(R.id.img);
            border = itemView.findViewById(R.id.border);
            pin = itemView.findViewById(R.id.pin);
            label = itemView.findViewById(R.id.label);

            final float radius = 16 * density;
            img.setOutlineProvider(new ViewOutlineProvider() {
                @Override
                public void getOutline(View view, Outline outline) {
                    outline.setRoundRect(0, 0, view.getWidth(), view.getHeight(), radius);
                }
            });
            img.setClipToOutline(true);

            itemView.setOnFocusChangeListener((v, hasFocus) -> {
                border.setSelected(hasFocus);
                card.animate().scaleX(hasFocus ? 1.10f : 1f).scaleY(hasFocus ? 1.10f : 1f)
                        .setDuration(150).start();
                label.animate().alpha(hasFocus ? 1f : 0.75f).setDuration(150).start();
                itemView.setTranslationZ(hasFocus ? 8 * density : 0);
            });
        }

        int dp(int v) {
            return (int) (v * density + 0.5f);
        }
    }
}
