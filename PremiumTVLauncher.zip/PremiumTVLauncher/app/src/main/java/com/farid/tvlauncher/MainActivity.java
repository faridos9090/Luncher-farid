package com.farid.tvlauncher;

import android.animation.ArgbEvaluator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.drawable.Drawable;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.util.DisplayMetrics;
import android.view.View;
import android.widget.TextView;

import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class MainActivity extends Activity implements AppAdapter.Listener {

    private static final String PREFS = "launcher";
    private static final String KEY_PINNED = "pinned";

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService io = Executors.newSingleThreadExecutor();
    private final ArgbEvaluator argb = new ArgbEvaluator();

    // Two palettes the background slowly blends between
    private final int[] paletteA = {0xFF070B22, 0xFF1A1360, 0xFF0C3B5C};
    private final int[] paletteB = {0xFF130A33, 0xFF3C1C74, 0xFF085A66};
    private final int[] current = {0xFF070B22, 0xFF1A1360, 0xFF0C3B5C};
    private float phase = 0f;
    private GradientDrawable bgDrawable;

    private RecyclerView grid;
    private AppAdapter adapter;
    private TextView greeting;
    private SharedPreferences prefs;
    private List<AppEntry> apps = new ArrayList<>();
    private boolean firstLoad = true;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver packageReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            loadApps();
        }
    };

    private final Runnable bgTick = new Runnable() {
        @Override
        public void run() {
            phase += 0.02f;
            float f = (float) ((Math.sin(phase) + 1.0) / 2.0);
            for (int i = 0; i < current.length; i++) {
                current[i] = (Integer) argb.evaluate(f, paletteA[i], paletteB[i]);
            }
            bgDrawable.setColors(current);
            handler.postDelayed(this, 150);
        }
    };

    private final Runnable greetingTick = new Runnable() {
        @Override
        public void run() {
            updateGreeting();
            handler.postDelayed(this, 60_000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        prefs = getSharedPreferences(PREFS, MODE_PRIVATE);

        setupBackground();

        greeting = findViewById(R.id.greeting);
        grid = findViewById(R.id.grid);

        DisplayMetrics dm = getResources().getDisplayMetrics();
        float widthDp = dm.widthPixels / dm.density;
        int span = Math.max(3, (int) ((widthDp - 96) / 190));
        grid.setLayoutManager(new GridLayoutManager(this, span));
        grid.setHasFixedSize(true);
        adapter = new AppAdapter(this);
        grid.setAdapter(adapter);

        setupButton(R.id.btnSettings, Settings.ACTION_SETTINGS);
        setupButton(R.id.btnWifi, Settings.ACTION_WIFI_SETTINGS);

        loadApps();
    }

    private void setupBackground() {
        bgDrawable = new GradientDrawable(GradientDrawable.Orientation.TL_BR, current.clone());
        findViewById(R.id.bg).setBackground(bgDrawable);

        GradientDrawable glow = new GradientDrawable();
        glow.setGradientType(GradientDrawable.RADIAL_GRADIENT);
        glow.setColors(new int[]{0x5500E5FF, 0x0000E5FF});
        glow.setGradientRadius(520 * getResources().getDisplayMetrics().density);
        glow.setGradientCenter(0.92f, 0.04f);
        findViewById(R.id.glow).setBackground(glow);
    }

    private void setupButton(int id, final String action) {
        View b = findViewById(id);
        b.setOnClickListener(v -> startSafely(new Intent(action)));
        b.setOnFocusChangeListener((v, hasFocus) ->
                v.animate().scaleX(hasFocus ? 1.18f : 1f).scaleY(hasFocus ? 1.18f : 1f).setDuration(150).start());
    }

    private void updateGreeting() {
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String g;
        if (h < 5) g = "Good night";
        else if (h < 12) g = "Good morning";
        else if (h < 18) g = "Good afternoon";
        else g = "Good evening";
        greeting.setText(String.format(Locale.getDefault(), "%s, %s", g, getString(R.string.user_name)));
    }

    @Override
    protected void onStart() {
        super.onStart();
        handler.post(bgTick);
        handler.post(greetingTick);
        if (!receiverRegistered) {
            IntentFilter f = new IntentFilter();
            f.addAction(Intent.ACTION_PACKAGE_ADDED);
            f.addAction(Intent.ACTION_PACKAGE_REMOVED);
            f.addAction(Intent.ACTION_PACKAGE_REPLACED);
            f.addDataScheme("package");
            registerReceiver(packageReceiver, f);
            receiverRegistered = true;
        }
    }

    @Override
    protected void onStop() {
        super.onStop();
        handler.removeCallbacks(bgTick);
        handler.removeCallbacks(greetingTick);
        if (receiverRegistered) {
            unregisterReceiver(packageReceiver);
            receiverRegistered = false;
        }
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        io.shutdownNow();
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        // Home button pressed while already on the launcher: jump back to the top
        grid.scrollToPosition(0);
        focusFirst();
    }

    @Override
    public void onBackPressed() {
        // A launcher never closes on Back
    }

    // ---------- Apps ----------

    private void loadApps() {
        final PackageManager pm = getPackageManager();
        final Set<String> pinned = new HashSet<>(prefs.getStringSet(KEY_PINNED, new HashSet<String>()));
        io.execute(() -> {
            final List<AppEntry> list = queryApps(pm, pinned);
            runOnUiThread(() -> {
                apps = list;
                adapter.setItems(apps);
                if (firstLoad) {
                    firstLoad = false;
                    focusFirst();
                }
            });
        });
    }

    private List<AppEntry> queryApps(PackageManager pm, Set<String> pinned) {
        List<AppEntry> out = new ArrayList<>();
        Set<String> seen = new HashSet<>();
        String[] categories = {Intent.CATEGORY_LEANBACK_LAUNCHER, Intent.CATEGORY_LAUNCHER};

        for (String category : categories) {
            Intent query = new Intent(Intent.ACTION_MAIN).addCategory(category);
            List<ResolveInfo> found = pm.queryIntentActivities(query, 0);
            for (ResolveInfo ri : found) {
                String pkg = ri.activityInfo.packageName;
                if (pkg.equals(getPackageName()) || !seen.add(pkg)) continue;

                Drawable banner = null;
                try {
                    banner = ri.activityInfo.loadBanner(pm);
                } catch (Throwable ignored) {
                }
                Drawable icon = ri.loadIcon(pm);

                Intent launch = new Intent(Intent.ACTION_MAIN)
                        .addCategory(category)
                        .setComponent(new ComponentName(pkg, ri.activityInfo.name))
                        .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);

                out.add(new AppEntry(String.valueOf(ri.loadLabel(pm)), pkg, launch, icon, banner,
                        pinned.contains(pkg)));
            }
        }
        sortApps(out);
        return out;
    }

    private void sortApps(List<AppEntry> list) {
        Collections.sort(list, (a, b) -> {
            if (a.pinned != b.pinned) return a.pinned ? -1 : 1;
            return a.label.compareToIgnoreCase(b.label);
        });
    }

    private void focusFirst() {
        grid.postDelayed(() -> {
            View v = grid.getChildAt(0);
            if (v != null) v.requestFocus();
        }, 200);
    }

    private void startSafely(Intent intent) {
        try {
            startActivity(intent);
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onClick(AppEntry entry) {
        try {
            startActivity(entry.intent);
        } catch (Exception e) {
            Intent fallback = getPackageManager().getLaunchIntentForPackage(entry.pkg);
            if (fallback != null) startSafely(fallback);
        }
    }

    @Override
    public void onLongClick(final AppEntry entry) {
        String[] options = {
                getString(entry.pinned ? R.string.unpin : R.string.pin),
                getString(R.string.app_info)
        };
        new AlertDialog.Builder(this)
                .setTitle(entry.label)
                .setItems(options, (dialog, which) -> {
                    if (which == 0) {
                        togglePin(entry);
                    } else {
                        startSafely(new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                                Uri.parse("package:" + entry.pkg)));
                    }
                })
                .show();
    }

    private void togglePin(AppEntry entry) {
        entry.pinned = !entry.pinned;
        Set<String> pinned = new HashSet<>();
        for (AppEntry a : apps) {
            if (a.pinned) pinned.add(a.pkg);
        }
        prefs.edit().putStringSet(KEY_PINNED, pinned).apply();
        sortApps(apps);
        adapter.setItems(apps);
        grid.scrollToPosition(0);
        focusFirst();
    }
}
